package Control;

import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import java.io.*;
import java.time.LocalDate;

public class Biblioteca {
    // --- RIFERIMENTI AI DATI (MODEL) ---
    private Libreria libreria;
    private Clienti clienti;
    private Prestiti prestiti;

    // --- LISTE PER JAVAFX (BINDING) ---
    private ObservableList<Libro> obsLibri;
    private ObservableList<Utente> obsUtenti;
    private ObservableList<Prestito> obsPrestiti;

    // --- LISTE FILTRATE (PER LA RICERCA) ---
    private FilteredList<Libro> filteredLibri;
    private FilteredList<Utente> filteredUtenti;

    private final String FILE_NAME = "biblioteca.dat";

    public Biblioteca() {
        if (!caricaDaFile()) {
            libreria = new Libreria();
            clienti = new Clienti();
            prestiti = new Prestiti();
        }
        startListe();
    }

    private void startListe() {
        // Wrapper Observable sulle liste del Model
        obsLibri = FXCollections.observableArrayList(libreria.getLibri());
        obsUtenti = FXCollections.observableArrayList(clienti.getUtenti());
        obsPrestiti = FXCollections.observableArrayList(prestiti.getListaPrestiti());

        // Wrapper Filtered per la ricerca (inizialmente mostrano tutto)
        filteredLibri = new FilteredList<>(obsLibri, p -> true);
        filteredUtenti = new FilteredList<>(obsUtenti, p -> true);
    }

    // --- ESPOSIZIONE DATI ALLA VIEW ---
    
    public FilteredList<Libro> getFilteredLibri() { return filteredLibri; }
    public FilteredList<Utente> getFilteredUtenti() { return filteredUtenti; }
    public ObservableList<Prestito> getObsPrestiti() { return obsPrestiti; }
    
    // Utili per i ComboBox (vogliamo la lista intera, non filtrata)
    public ObservableList<Libro> getObsLibri() { return obsLibri; }
    public ObservableList<Utente> getObsUtenti() { return obsUtenti; }

    // --- LOGICA DI RICERCA ---

    public void filtraLibri(String query) {
        filteredLibri.setPredicate(libro -> {
            if (query == null || query.isEmpty()) return true;
            String lower = query.toLowerCase();
            return libro.getTitolo().toLowerCase().contains(lower) || 
                   libro.getAutori().toLowerCase().contains(lower) ||
                   libro.getIsbn().toLowerCase().contains(lower);
        });
    }

    public void filtraUtenti(String query) {
        filteredUtenti.setPredicate(utente -> {
            if (query == null || query.isEmpty()) return true;
            String lower = query.toLowerCase();
            return utente.getNome().toLowerCase().contains(lower) || 
                   utente.getCognome().toLowerCase().contains(lower) ||
                   utente.getMatricola().toLowerCase().contains(lower);
        });
    }

    // --- METODI OPERATIVI (CRUD) ---

    public void inserisciLibro(String titolo, String autori, String annoStr, String isbn, String copieStr) throws Exception {
        checkValiditàCampiLibro(titolo, annoStr, copieStr);
        if (libreria.esisteLibro(isbn)) throw new Exception("ISBN già presente.");

        Libro l = new Libro(titolo, autori, Integer.parseInt(annoStr), isbn, Integer.parseInt(copieStr));
        libreria.aggiungiLibro(l);
        obsLibri.add(l); // Aggiorna UI
        salvaSuFile();
    }

    public void eliminaLibro(Libro l) throws Exception {
        if (prestiti.isLibroInPrestito(l)) throw new Exception("Impossibile eliminare: Libro in prestito.");
        libreria.rimuoviLibro(l);
        obsLibri.remove(l);
        salvaSuFile();
    }

    public void inserisciUtente(String nome, String cognome, String matricola, String email) throws Exception {
        if (nome.isEmpty() || cognome.isEmpty() || matricola.isEmpty()) throw new Exception("Campi obbligatori mancanti.");
        if (clienti.esisteUtente(matricola)) throw new Exception("Matricola già esistente.");

        Utente u = new Utente(nome, cognome, matricola, email);
        clienti.aggiungiUtente(u);
        obsUtenti.add(u);
        salvaSuFile();
    }

    public void eliminaUtente(Utente u) throws Exception {
        if (u.getPrestitiAttivi() > 0) throw new Exception("Impossibile eliminare: Utente ha prestiti attivi.");
        clienti.rimuoviUtente(u);
        obsUtenti.remove(u);
        salvaSuFile();
    }

    public void registraPrestito(Utente u, Libro l, LocalDate data) throws Exception {
        if (u == null || l == null || data == null) throw new Exception("Dati incompleti.");
        
        // Verifica Vincoli (Logic Check)
        if (l.getCopieDisponibili() <= 0) throw new Exception("Nessuna copia disponibile.");
        if (u.getPrestitiAttivi() >= 3) throw new Exception("Limite 3 prestiti raggiunto.");

        Prestito p = new Prestito(u, l, data);
        prestiti.aggiungiPrestito(p);
        obsPrestiti.add(p);
        
        // Forza aggiornamento contatori nelle tabelle
        refreshItem(obsLibri, l);
        refreshItem(obsUtenti, u);
        
        salvaSuFile();
    }

    public void restituzionePrestito(Prestito p) {
        prestiti.rimuoviPrestito(p);
        obsPrestiti.remove(p);
        refreshItem(obsLibri, p.getLibro());
        refreshItem(obsUtenti, p.getUtente());
        salvaSuFile();
    }
    
    // Metodo generico per forzare il refresh visivo di un oggetto modificato nella lista
    private <T> void refreshItem(ObservableList<T> list, T item) {
        int index = list.indexOf(item);
        if (index >= 0) list.set(index, item);
    }

    // Metodo chiamato dalla View dopo aver modificato un oggetto tramite Dialog
    public void salvaModifiche() {
        salvaSuFile();
    }

    // --- HELPER DI VALIDAZIONE (PRIVATI) ---
    
    private void checkValiditàCampiLibro(String titolo, String anno, String copie) throws Exception {
        if (titolo == null || titolo.isEmpty()) throw new Exception("Il titolo è obbligatorio.");
        try {
            Integer.parseInt(anno);
            int c = Integer.parseInt(copie);
            if (c < 0) throw new Exception("Le copie non possono essere negative.");
        } catch (NumberFormatException e) {
            throw new Exception("Anno e Copie devono essere numeri interi.");
        }
    }

    // --- PERSISTENZA ---

    private void salvaSuFile() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(FILE_NAME))) {
            out.writeObject(libreria);
            out.writeObject(clienti);
            out.writeObject(prestiti);
        } catch (IOException e) { e.printStackTrace(); }
    }

    private boolean caricaDaFile() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(FILE_NAME))) {
            libreria = (Libreria) in.readObject();
            clienti = (Clienti) in.readObject();
            prestiti = (Prestiti) in.readObject();
            return true;
        } catch (Exception e) { return false; }
    }
}