package View;

import Control.Biblioteca;
import Model.*;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import java.time.LocalDate;
import javafx.scene.layout.GridPane;

public class MainController {

    // --- COLLEGAMENTI AL FILE FXML ---
    
    // Pannelli
    @FXML private VBox paneLibri;
    @FXML private VBox paneUtenti;
    @FXML private VBox panePrestiti;

    // Campi Ricerca
    @FXML private TextField searchLibri;
    @FXML private TextField searchUtenti;

    // Tabella Libri
    @FXML private TableView<Libro> tableLibri;
    @FXML private TableColumn<Libro, String> colLibTitolo;
    @FXML private TableColumn<Libro, String> colLibAutori;
    @FXML private TableColumn<Libro, Integer> colLibAnno;
    @FXML private TableColumn<Libro, String> colLibIsbn;
    @FXML private TableColumn<Libro, String> colLibCopie;
    @FXML private TableColumn<Libro, Void> colLibAzioni;

    // Tabella Utenti
    @FXML private TableView<Utente> tableUtenti;
    @FXML private TableColumn<Utente, String> colUtNome;
    @FXML private TableColumn<Utente, String> colUtCognome;
    @FXML private TableColumn<Utente, String> colUtMatr;
    @FXML private TableColumn<Utente, Integer> colUtPrestiti;
    @FXML private TableColumn<Utente, Void> colUtAzioni;

    // Tabella Prestiti
    @FXML private TableView<Prestito> tablePrestiti;
    @FXML private TableColumn<Prestito, String> colPresUtente;
    @FXML private TableColumn<Prestito, String> colPresLibro;
    @FXML private TableColumn<Prestito, String> colPresData;
    @FXML private TableColumn<Prestito, String> colPresStato;
    @FXML private TableColumn<Prestito, Void> colPresAzioni;

    // --- RIFERIMENTO ALLA LOGICA DI BUSINESS ---
    private Biblioteca biblioteca;

    // --- INIZIALIZZAZIONE ---
    @FXML
    public void initialize() {
        // 1. Instanzia il Controller Logico (Model Manager)
        biblioteca = new Biblioteca();

        // 2. Configura le Colonne (Mapping dati -> colonne)
        configuraColonneLibri();
        configuraColonneUtenti();
        configuraColonnePrestiti();

        // 3. Binding dei Dati (Collega le liste del controller alle tabelle)
        tableLibri.setItems(biblioteca.getFilteredLibri());
        tableUtenti.setItems(biblioteca.getFilteredUtenti());
        tablePrestiti.setItems(biblioteca.getObsPrestiti());

        // 4. Listener per la Ricerca
        searchLibri.textProperty().addListener((obs, oldVal, newVal) -> biblioteca.filtraLibri(newVal));
        searchUtenti.textProperty().addListener((obs, oldVal, newVal) -> biblioteca.filtraUtenti(newVal));
    }

    // --- CONFIGURAZIONE COLONNE (Copia della logica precedente, ma adattata all'FXML) ---
    
    private void configuraColonneLibri() {
        colLibTitolo.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getTitolo()));
        colLibAutori.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getAutori()));
        colLibAnno.setCellValueFactory(d -> new SimpleObjectProperty<>(d.getValue().getAnno()));
        colLibIsbn.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getIsbn()));
        colLibCopie.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getCopieDisponibili() + "/" + d.getValue().getCopieTotali()));

        colLibAzioni.setCellFactory(p -> new TableCell<Libro, Void>() {
            private final Button btnDel = new Button("Elim.");
            { btnDel.setStyle("-fx-text-fill: red;"); 
              btnDel.setOnAction(e -> {
                  try { biblioteca.eliminaLibro(getTableView().getItems().get(getIndex())); } 
                  catch (Exception ex) { alertErrore(ex.getMessage()); }
              }); 
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnDel);
            }
        });
    }

    private void configuraColonneUtenti() {
        colUtNome.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getNome()));
        colUtCognome.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getCognome()));
        colUtMatr.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getMatricola()));
        colUtPrestiti.setCellValueFactory(d -> new SimpleObjectProperty<>(d.getValue().getPrestitiAttivi()));
        
        colUtAzioni.setCellFactory(p -> new TableCell<Utente, Void>() {
            private final Button btnDel = new Button("Elim.");
            { btnDel.setStyle("-fx-text-fill: red;"); 
              btnDel.setOnAction(e -> {
                  try { biblioteca.eliminaUtente(getTableView().getItems().get(getIndex())); } 
                  catch (Exception ex) { alertErrore(ex.getMessage()); }
              });
            }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnDel);
            }
        });
    }

    private void configuraColonnePrestiti() {
        colPresUtente.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getUtente().getCognome()));
        colPresLibro.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getLibro().getTitolo()));
        colPresData.setCellValueFactory(d -> new SimpleStringProperty(d.getValue().getDataRestituzionePrevista().toString()));
        
        colPresStato.setCellFactory(c -> new TableCell<Prestito, String>() {
            @Override protected void updateItem(String item, boolean empty) {
                super.updateItem(item, empty);
                if (empty || getTableRow() == null || getTableRow().getItem() == null) {
                    setText(null);
                } else {
                    Prestito p = (Prestito) getTableRow().getItem();
                    setText(p.isInRitardo() ? "RITARDO" : "Attivo");
                    setTextFill(p.isInRitardo() ? Color.RED : Color.GREEN);
                }
            }
        });

        colPresAzioni.setCellFactory(p -> new TableCell<Prestito, Void>() {
            private final Button btnRet = new Button("Rientro");
            { btnRet.setOnAction(e -> biblioteca.restituzionePrestito(getTableView().getItems().get(getIndex()))); }
            @Override protected void updateItem(Void item, boolean empty) {
                super.updateItem(item, empty);
                setGraphic(empty ? null : btnRet);
            }
        });
    }

    // --- NAVIGAZIONE (Switch Pannelli) ---

    @FXML public void showLibri() { switchView(paneLibri); }
    @FXML public void showUtenti() { switchView(paneUtenti); }
    @FXML public void showPrestiti() { switchView(panePrestiti); }

    private void switchView(VBox paneToShow) {
        paneLibri.setVisible(false);
        paneUtenti.setVisible(false);
        panePrestiti.setVisible(false);
        paneToShow.setVisible(true);
    }

    // --- AZIONI BOTTONI (Popup) ---
    // (Qui manteniamo la creazione dei Dialog in Java perché è semplice e veloce)

    @FXML
    public void onNuovoLibro() {
        Dialog<ButtonType> d = new Dialog<>();
        d.setTitle("Nuovo Libro");
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10);
        
        TextField t1 = new TextField(), t2 = new TextField(), t3 = new TextField(), t4 = new TextField(), t5 = new TextField();
        grid.addRow(0, new Label("Titolo:"), t1);
        grid.addRow(1, new Label("Autori:"), t2);
        grid.addRow(2, new Label("Anno:"), t3);
        grid.addRow(3, new Label("ISBN:"), t4);
        grid.addRow(4, new Label("Copie:"), t5);
        d.getDialogPane().setContent(grid);
        
        d.showAndWait().ifPresent(r -> {
            if (r == ButtonType.OK) {
                try { biblioteca.inserisciLibro(t1.getText(), t2.getText(), t3.getText(), t4.getText(), t5.getText()); } 
                catch (Exception e) { alertErrore(e.getMessage()); }
            }
        });
    }

    @FXML
    public void onNuovoUtente() {
        Dialog<ButtonType> d = new Dialog<>();
        d.setTitle("Nuovo Utente");
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10);
        
        TextField t1 = new TextField(), t2 = new TextField(), t3 = new TextField(), t4 = new TextField();
        grid.addRow(0, new Label("Nome:"), t1);
        grid.addRow(1, new Label("Cognome:"), t2);
        grid.addRow(2, new Label("Matricola:"), t3);
        grid.addRow(3, new Label("Email:"), t4);
        d.getDialogPane().setContent(grid);
        
        d.showAndWait().ifPresent(r -> {
            if (r == ButtonType.OK) {
                try { biblioteca.inserisciUtente(t1.getText(), t2.getText(), t3.getText(), t4.getText()); } 
                catch (Exception e) { alertErrore(e.getMessage()); }
            }
        });
    }

    @FXML
    public void onNuovoPrestito() {
        Dialog<ButtonType> d = new Dialog<>();
        d.setTitle("Nuovo Prestito");
        d.getDialogPane().getButtonTypes().addAll(ButtonType.OK, ButtonType.CANCEL);
        GridPane grid = new GridPane(); grid.setHgap(10); grid.setVgap(10);
        
        ComboBox<Utente> cmbU = new ComboBox<>(biblioteca.getObsUtenti());
        ComboBox<Libro> cmbL = new ComboBox<>(biblioteca.getObsLibri());
        DatePicker dp = new DatePicker(LocalDate.now().plusDays(30));
        
        grid.addRow(0, new Label("Utente:"), cmbU);
        grid.addRow(1, new Label("Libro:"), cmbL);
        grid.addRow(2, new Label("Restituzione:"), dp);
        d.getDialogPane().setContent(grid);
        
        d.showAndWait().ifPresent(r -> {
            if (r == ButtonType.OK) {
                try { biblioteca.registraPrestito(cmbU.getValue(), cmbL.getValue(), dp.getValue()); } 
                catch (Exception e) { alertErrore(e.getMessage()); }
            }
        });
    }

    private void alertErrore(String msg) { new Alert(Alert.AlertType.ERROR, msg).show(); }
}