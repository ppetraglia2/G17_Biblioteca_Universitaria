package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Clienti implements Serializable {
    private List<Utente> utenti;

    public Clienti() {
        this.utenti = new ArrayList<>();
    }

    public void aggiungiUtente(Utente utente) throws Exception {
        if (esisteUtente(utente.getMatricola())) {
            throw new Exception("Utente con questa matricola già registrato.");
        }
        utenti.add(utente);
    }

    public void rimuoviUtente(Utente utente) {
        utenti.remove(utente);
    }

    public boolean esisteUtente(String matricola) {
        return utenti.stream().anyMatch(u -> u.getMatricola().equals(matricola));
    }

    public List<Utente> getUtenti() {
        return utenti;
    }
}