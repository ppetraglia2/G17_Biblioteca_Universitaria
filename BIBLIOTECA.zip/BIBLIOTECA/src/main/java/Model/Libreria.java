package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Libreria implements Serializable {
    private List<Libro> libri;

    public Libreria() {
        this.libri = new ArrayList<>();
    }

    public void aggiungiLibro(Libro libro) throws Exception {
        if (esisteLibro(libro.getIsbn())) {
            throw new Exception("Libro con questo ISBN già presente.");
        }
        libri.add(libro);
    }

    public void rimuoviLibro(Libro libro) {
        libri.remove(libro);
    }

    public boolean esisteLibro(String isbn) {
        return libri.stream().anyMatch(l -> l.getIsbn().equals(isbn));
    }

    public List<Libro> getLibri() {
        return libri;
    }
    
    public List<Libro> cercaPerTitolo(String query) {
        return libri.stream()
                .filter(l -> l.getTitolo().toLowerCase().contains(query.toLowerCase()))
                .collect(Collectors.toList());
    }
}