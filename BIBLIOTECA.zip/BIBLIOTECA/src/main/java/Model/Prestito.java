package Model;

import java.io.Serializable;
import java.time.LocalDate;

public class Prestito implements Serializable {
    private Utente utente;
    private Libro libro;
    private LocalDate dataRestituzionePrevista;

    public Prestito(Utente utente, Libro libro, LocalDate dataRestituzionePrevista) {
        this.utente = utente;
        this.libro = libro;
        this.dataRestituzionePrevista = dataRestituzionePrevista;
    }

    public Utente getUtente() { return utente; }
    public Libro getLibro() { return libro; }
    public LocalDate getDataRestituzionePrevista() { return dataRestituzionePrevista; }

    public boolean isInRitardo() {
        return LocalDate.now().isAfter(dataRestituzionePrevista);
    }
}