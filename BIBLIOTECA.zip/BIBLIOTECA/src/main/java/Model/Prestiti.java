package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Prestiti implements Serializable {
    private List<Prestito> listaPrestiti;

    public Prestiti() {
        this.listaPrestiti = new ArrayList<>();
    }

    public void aggiungiPrestito(Prestito prestito) throws Exception {
        if (prestito.getLibro().getCopieDisponibili() <= 0) {
            throw new Exception("Nessuna copia disponibile per questo libro.");
        }
        if (prestito.getUtente().getPrestitiAttivi() >= 3) {
            throw new Exception("L'utente ha raggiunto il limite massimo di 3 prestiti.");
        }
        
        listaPrestiti.add(prestito);
        prestito.getLibro().decrementaCopie();
        prestito.getUtente().incrementaPrestiti();
    }

    public void rimuoviPrestito(Prestito prestito) {
        listaPrestiti.remove(prestito);
        prestito.getLibro().incrementaCopie();
        prestito.getUtente().decrementaPrestiti();
    }
    
    public boolean isLibroInPrestito(Libro libro) {
        return listaPrestiti.stream().anyMatch(p -> p.getLibro().equals(libro));
    }

    public List<Prestito> getListaPrestiti() {
        return listaPrestiti;
    }
}