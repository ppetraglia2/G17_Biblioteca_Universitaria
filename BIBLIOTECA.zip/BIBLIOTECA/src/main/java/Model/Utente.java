package Model;

import java.io.Serializable;
import java.util.Objects;

public class Utente implements Serializable {
    private String nome;
    private String cognome;
    private String matricola;
    private String email;
    private int prestitiAttivi; // Contatore prestiti

    public Utente(String nome, String cognome, String matricola, String email) {
        this.nome = nome;
        this.cognome = cognome;
        this.matricola = matricola;
        this.email = email;
        this.prestitiAttivi = 0;
    }

    // Getters e Setters
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getCognome() { return cognome; }
    public void setCognome(String cognome) { this.cognome = cognome; }

    public String getMatricola() { return matricola; }
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public int getPrestitiAttivi() { return prestitiAttivi; }
    public void incrementaPrestiti() { prestitiAttivi++; }
    public void decrementaPrestiti() { if(prestitiAttivi > 0) prestitiAttivi--; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Utente utente = (Utente) o;
        return Objects.equals(matricola, utente.matricola);
    }

    @Override
    public int hashCode() {
        return Objects.hash(matricola);
    }

    @Override
    public String toString() {
        return cognome + " " + nome + " (" + matricola + ")";
    }
}