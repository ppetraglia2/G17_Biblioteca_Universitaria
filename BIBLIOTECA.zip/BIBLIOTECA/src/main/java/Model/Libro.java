package Model;

import java.io.Serializable;
import java.util.Objects;

public class Libro implements Serializable {
    private String titolo;
    private String autori; // Lista nomi separati da virgola
    private int anno;
    private String isbn;
    private int copieTotali;
    private int copieDisponibili;

    public Libro(String titolo, String autori, int anno, String isbn, int copieTotali) {
        this.titolo = titolo;
        this.autori = autori;
        this.anno = anno;
        this.isbn = isbn;
        this.copieTotali = copieTotali;
        this.copieDisponibili = copieTotali;
    }

    // Getters e Setters
    public String getTitolo() { return titolo; }
    public void setTitolo(String titolo) { this.titolo = titolo; }
    
    public String getAutori() { return autori; }
    public void setAutori(String autori) { this.autori = autori; }
    
    public int getAnno() { return anno; }
    public void setAnno(int anno) { this.anno = anno; }
    
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }
    
    public int getCopieTotali() { return copieTotali; }
    public void setCopieTotali(int copieTotali) { 
        // Aggiorna anche le disponibili in base alla differenza
        int diff = copieTotali - this.copieTotali;
        this.copieTotali = copieTotali;
        this.copieDisponibili += diff;
    }
    
    public int getCopieDisponibili() { return copieDisponibili; }
    
    public void decrementaCopie() {
        if (copieDisponibili > 0) copieDisponibili--;
    }
    
    public void incrementaCopie() {
        if (copieDisponibili < copieTotali) copieDisponibili++;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Libro libro = (Libro) o;
        return Objects.equals(isbn, libro.isbn);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }
    
    @Override
    public String toString() {
        return titolo + " (" + isbn + ")";
    }
}